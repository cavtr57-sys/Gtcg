
import 'package:flutter/material.dart';

void main() {
  runApp(const SertAdamLifeApp());
}

class SertAdamLifeApp extends StatelessWidget {
  const SertAdamLifeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Sert Adam Life',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF050914),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF8A2BE2),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int index = 0;
  int coins = 12450;
  int gems = 320;

  void addCoins(int amount) {
    setState(() => coins += amount);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('+$amount jeton kazandın!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(coins: coins, gems: gems, onReward: () => addCoins(100)),
      const GamesPage(),
      const EducationPage(),
      const ShopPage(),
      const ProfilePage(),
    ];

    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        backgroundColor: const Color(0xFF0B1122),
        indicatorColor: const Color(0xFF6F20C9),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'Ana Sayfa'),
          NavigationDestination(icon: Icon(Icons.sports_esports), label: 'Oyunlar'),
          NavigationDestination(icon: Icon(Icons.menu_book), label: 'Eğitim'),
          NavigationDestination(icon: Icon(Icons.shopping_cart), label: 'Mağaza'),
          NavigationDestination(icon: Icon(Icons.person), label: 'Profil'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final int coins;
  final int gems;
  final VoidCallback onReward;

  const HomePage({
    super.key,
    required this.coins,
    required this.gems,
    required this.onReward,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            const Icon(Icons.menu, size: 34),
            const SizedBox(width: 10),
            const Expanded(
              child: Text(
                'SERT ADAM\nLIFE',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  height: .9,
                ),
              ),
            ),
            _Balance(icon: Icons.monetization_on, text: '$coins'),
            const SizedBox(width: 8),
            _Balance(icon: Icons.diamond, text: '$gems'),
            const SizedBox(width: 8),
            const Icon(Icons.notifications, size: 28),
          ],
        ),
        const SizedBox(height: 18),
        _ProfileCard(),
        const SizedBox(height: 18),
        GestureDetector(
          onTap: onReward,
          child: _Banner(
            title: 'GÜNLÜK GİRİŞ YAP',
            subtitle: 'JETON KAZAN!',
            body: 'Her gün giriş yap, ödülleri kap!',
            icon: Icons.card_giftcard,
          ),
        ),
        const SizedBox(height: 18),
        _SectionTitle('OYUNLAR', Icons.sports_esports),
        const SizedBox(height: 10),
        SizedBox(
          height: 150,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: const [
              GameCard('⚽', '2D FUTBOL', Colors.green),
              GameCard('🏟️', '3D FUTBOL', Colors.blue),
              GameCard('🎯', 'SİLAH OYUNLARI', Colors.orange),
              GameCard('🏃', 'PARKUR', Colors.indigo),
              GameCard('🧩', 'BULMACA', Colors.purple),
            ],
          ),
        ),
        const SizedBox(height: 18),
        _SectionTitle('EĞİTİM', Icons.school),
        const SizedBox(height: 10),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: const [
            SubjectCard('123', 'MATEMATİK', Colors.green),
            SubjectCard('AB', 'İNGİLİZCE', Colors.blue),
            SubjectCard('ق', 'ARAPÇA', Colors.teal),
            SubjectCard('☪', 'DİN BİLGİSİ', Colors.brown),
            SubjectCard('📖', 'HİKAYELER', Colors.red),
          ],
        ),
        const SizedBox(height: 18),
        Row(
          children: const [
            Expanded(child: MiniCard(Icons.smart_toy, 'YAPAY ZEKA\nSOHBET')),
            SizedBox(width: 10),
            Expanded(child: MiniCard(Icons.groups, 'SOHBET ODALARI')),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: const [
            Expanded(child: MiniCard(Icons.play_circle, 'VİDEOLAR')),
            SizedBox(width: 10),
            Expanded(child: MiniCard(Icons.music_note, 'MÜZİK')),
          ],
        ),
        const SizedBox(height: 18),
        _InfoCard(
          title: 'NASIL PARA KAZANILIR?',
          text: 'İnternetten para kazanma yollarını öğren!',
          icon: Icons.attach_money,
        ),
        const SizedBox(height: 10),
        _InfoCard(
          title: 'DEVLET İŞLERİ REHBERİ',
          text: 'e-Devlet kullanımını öğren ve işlemlerini kolayca yap!',
          icon: Icons.account_balance,
        ),
      ],
    );
  }
}

class GamesPage extends StatelessWidget {
  const GamesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final games = [
      ('⚽', '2D Futbol'),
      ('🏟️', '3D Futbol'),
      ('🎯', 'Silah Oyunları'),
      ('🏃', 'Parkur'),
      ('🧩', 'Bulmaca'),
    ];
    return _SimplePage(
      title: 'Oyunlar',
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 1.1,
        ),
        itemCount: games.length,
        itemBuilder: (_, i) => GameCard(games[i].$1, games[i].$2, Colors.deepPurple),
      ),
    );
  }
}

class EducationPage extends StatelessWidget {
  const EducationPage({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('123', 'Matematik'),
      ('AB', 'İngilizce'),
      ('ق', 'Arapça'),
      ('☪', 'Din Bilgisi'),
      ('📖', 'Hikaye Kitapları'),
    ];
    return _SimplePage(
      title: 'Eğitim',
      child: Column(
        children: items
            .map((e) => ListTile(
                  leading: CircleAvatar(child: Text(e.$1)),
                  title: Text(e.$2),
                  trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                  onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('${e.$2} açılıyor...')),
                  ),
                ))
            .toList(),
      ),
    );
  }
}

class ShopPage extends StatelessWidget {
  const ShopPage({super.key});

  @override
  Widget build(BuildContext context) {
    return _SimplePage(
      title: 'Jeton Mağazası',
      child: Column(
        children: [
          _ShopItem('1.000 Jeton', '₺19,99'),
          _ShopItem('5.000 Jeton', '₺79,99'),
          _ShopItem('10.000 Jeton', '₺129,99'),
        ],
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return _SimplePage(
      title: 'Profil',
      child: const Column(
        children: [
          CircleAvatar(radius: 55, child: Icon(Icons.person, size: 60)),
          SizedBox(height: 12),
          Text('SertAdam', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
          Text('Seviye 25'),
          SizedBox(height: 20),
          ListTile(leading: Icon(Icons.emoji_events), title: Text('Başarılar'), trailing: Text('28')),
          ListTile(leading: Icon(Icons.local_fire_department), title: Text('Günlük Seri'), trailing: Text('12 gün')),
          ListTile(leading: Icon(Icons.people), title: Text('Arkadaşlar'), trailing: Text('12')),
        ],
      ),
    );
  }
}

class _SimplePage extends StatelessWidget {
  final String title;
  final Widget child;
  const _SimplePage({required this.title, required this.child});

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(title, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
          const SizedBox(height: 18),
          child,
        ],
      );
}

class _Balance extends StatelessWidget {
  final IconData icon;
  final String text;
  const _Balance({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.white24),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(children: [Icon(icon, size: 18), const SizedBox(width: 5), Text(text)]),
      );
}

class _ProfileCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: const LinearGradient(colors: [Color(0xFF172B55), Color(0xFF0B142B)]),
          border: Border.all(color: Colors.blueAccent.withOpacity(.4)),
        ),
        child: Row(
          children: [
            const CircleAvatar(radius: 38, child: Icon(Icons.person, size: 42)),
            const SizedBox(width: 14),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('SertAdam', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
                  SizedBox(height: 5),
                  Text('Seviye 25'),
                  SizedBox(height: 8),
                  LinearProgressIndicator(value: .785),
                  SizedBox(height: 4),
                  Text('7.850 / 10.000'),
                ],
              ),
            ),
          ],
        ),
      );
}

class _Banner extends StatelessWidget {
  final String title, subtitle, body;
  final IconData icon;
  const _Banner({required this.title, required this.subtitle, required this.body, required this.icon});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: const LinearGradient(colors: [Color(0xFF30116E), Color(0xFF101C4C)]),
          border: Border.all(color: Colors.purpleAccent),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                  Text(subtitle, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 5),
                  Text(body),
                  const SizedBox(height: 12),
                  FilledButton(onPressed: () {}, child: const Text('ÖDÜL AL')),
                ],
              ),
            ),
            Icon(icon, size: 70),
          ],
        ),
      );
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final IconData icon;
  const _SectionTitle(this.title, this.icon);

  @override
  Widget build(BuildContext context) => Row(
        children: [
          Icon(icon),
          const SizedBox(width: 8),
          Text(title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          const Spacer(),
          const Text('Tümünü Gör ›'),
        ],
      );
}

class GameCard extends StatelessWidget {
  final String emoji, title;
  final Color color;
  const GameCard(this.emoji, this.title, this.color);

  @override
  Widget build(BuildContext context) => Container(
        width: 150,
        margin: const EdgeInsets.only(right: 10),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.withOpacity(.35),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: color),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(emoji, style: const TextStyle(fontSize: 42)),
            const SizedBox(height: 8),
            Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
      );
}

class SubjectCard extends StatelessWidget {
  final String symbol, title;
  final Color color;
  const SubjectCard(this.symbol, this.title, this.color);

  @override
  Widget build(BuildContext context) => Container(
        width: 145,
        height: 105,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: color.withOpacity(.28),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: color),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(symbol, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            const SizedBox(height: 5),
            Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
      );
}

class MiniCard extends StatelessWidget {
  final IconData icon;
  final String title;
  const MiniCard(this.icon, this.title);

  @override
  Widget build(BuildContext context) => Container(
        height: 85,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFF10152A),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.purpleAccent.withOpacity(.7)),
        ),
        child: Row(
          children: [
            Icon(icon, size: 32),
            const SizedBox(width: 8),
            Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold))),
          ],
        ),
      );
}

class _InfoCard extends StatelessWidget {
  final String title, text;
  final IconData icon;
  const _InfoCard({required this.title, required this.text, required this.icon});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: const Color(0xFF0E2430),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.greenAccent.withOpacity(.5)),
        ),
        child: Row(
          children: [
            Icon(icon, size: 45),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 5),
                  Text(text),
                ],
              ),
            ),
          ],
        ),
      );
}

class _ShopItem extends StatelessWidget {
  final String title, price;
  const _ShopItem(this.title, this.price);

  @override
  Widget build(BuildContext context) => Card(
        child: ListTile(
          leading: const Icon(Icons.monetization_on, size: 36),
          title: Text(title),
          subtitle: const Text('Jeton paketi'),
          trailing: FilledButton(onPressed: () {}, child: Text(price)),
        ),
      );
}
