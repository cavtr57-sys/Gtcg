# Sert Adam Life

Bu proje, gönderdiğin Sert Adam Life tasarımının Flutter ile hazırlanmış başlangıç mobil uygulamasıdır.

## Çalıştırma
1. Flutter SDK kur.
2. Bu klasörde terminal aç.
3. `flutter pub get`
4. Android cihaz/emülatör bağla.
5. `flutter run`

APK için:
`flutter build apk --release`

Not: Bu sürüm arayüz/prototip aşamasındadır. Gerçek kullanıcı hesabı, sunucu, mesajlaşma, online oyunlar, ödeme ve jeton altyapısı ayrıca bağlanmalıdır.
